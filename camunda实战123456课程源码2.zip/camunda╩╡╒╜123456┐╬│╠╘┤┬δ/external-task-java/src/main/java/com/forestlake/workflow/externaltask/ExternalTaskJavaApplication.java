package com.forestlake.workflow.externaltask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExternalTaskJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExternalTaskJavaApplication.class, args);
    }

}
